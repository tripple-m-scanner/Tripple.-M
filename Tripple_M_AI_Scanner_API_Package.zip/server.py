import os, json
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

HOST = "0.0.0.0"
PORT = int(os.environ.get("PORT", "8080"))
API_KEY = os.environ.get("OPENAI_API_KEY", "")
MODEL = os.environ.get("OPENAI_MODEL", "gpt-5.6-luna")

SYSTEM = """You are the AI Business Opportunity Scanner for Tripple M.
Analyze a small business owner's answers and identify the highest-value business problem that could be improved with AI.
Return ONLY valid JSON with:
overall_score (integer 1-100),
level (string),
summary (string),
winner (string),
solution (string),
why (string),
pain (integer 1-10),
frequency (integer 1-10),
impact (integer 1-10),
ai_fit (integer 1-10),
ease (integer 1-10),
workflow (string),
other_opportunities (array of objects with name, score, solution).
Do not invent facts. Treat the scores as estimates. Never claim guaranteed revenue.
Prioritize concrete, repetitive, measurable workflows. Keep recommendations practical for a small business."""

def fallback(data):
    text = " ".join(str(v) for v in data.values()).lower()
    candidates = [
        ("Customer enquiries and conversations","AI Customer Conversation Assistant",["customer","reply","question","whatsapp","enquir","conversation","price"],90),
        ("Lead generation and follow-up","AI Lead Follow-up System",["lead","follow","prospect","sales","sell","conversion"],88),
        ("Content and marketing production","AI Content Engine",["content","post","instagram","facebook","marketing","social"],82),
        ("Bookings and scheduling","AI Booking & Intake Assistant",["booking","appointment","schedule","calendar"],80),
        ("Repetitive administration and data entry","AI Admin/Data Workflow",["data","entry","spreadsheet","excel","admin","manual"],78),
    ]
    ranked=[]
    for name,sol,keys,base in candidates:
        hits=sum(k in text for k in keys)
        ranked.append((base+min(9,hits*2),name,sol))
    ranked.sort(reverse=True)
    s,n,sol=ranked[0]
    return {
        "overall_score":s,"level":"HIGH OPPORTUNITY" if s>=80 else "MEDIUM OPPORTUNITY",
        "summary":"The scanner found a practical workflow opportunity worth validating first.",
        "winner":n,"solution":sol,
        "why":"The problem appears suitable for an AI-assisted workflow because it is repeatable and potentially measurable.",
        "pain":8,"frequency":8,"impact":9,"ai_fit":9,"ease":8,
        "workflow":"Customer/business input → AI processes the request using approved information → useful output → human review for exceptions.",
        "other_opportunities":[{"name":x[1],"score":x[0],"solution":x[2]} for x in ranked[1:4]]
    }

def openai_analyze(data):
    from urllib.request import Request, urlopen
    prompt = json.dumps(data, ensure_ascii=False)
    body = json.dumps({
        "model": MODEL,
        "input": [
            {"role":"system","content":SYSTEM},
            {"role":"user","content":"Analyze this business intake:\n"+prompt}
        ]
    }).encode()
    req=Request("https://api.openai.com/v1/responses", data=body,
                headers={"Authorization":"Bearer "+API_KEY,"Content-Type":"application/json"})
    with urlopen(req, timeout=45) as r:
        obj=json.loads(r.read().decode())
    # Responses API commonly returns output text in output[].content[].text
    chunks=[]
    for item in obj.get("output",[]):
        for c in item.get("content",[]):
            if isinstance(c,dict) and c.get("text"):
                chunks.append(c["text"])
    raw="".join(chunks).strip()
    raw=raw.removeprefix("```json").removesuffix("```").strip()
    return json.loads(raw)

class Handler(BaseHTTPRequestHandler):
    def send_json(self, code, obj):
        payload=json.dumps(obj,ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin","*")
        self.send_header("Access-Control-Allow-Headers","Content-Type")
        self.end_headers()
        self.wfile.write(payload)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin","*")
        self.send_header("Access-Control-Allow-Headers","Content-Type")
        self.send_header("Access-Control-Allow-Methods","POST, OPTIONS")
        self.end_headers()

    def do_POST(self):
        if self.path != "/api/scan":
            return self.send_json(404,{"error":"Not found"})
        try:
            length=int(self.headers.get("Content-Length","0"))
            data=json.loads(self.rfile.read(length).decode())
            if API_KEY:
                try:
                    result=openai_analyze(data)
                    return self.send_json(200,{"mode":"ai","result":result})
                except Exception as exc:
                    # Never expose API details to the visitor.
                    print("OpenAI request failed:",repr(exc))
            return self.send_json(200,{"mode":"demo","result":fallback(data)})
        except Exception:
            return self.send_json(400,{"error":"Invalid request"})

    def do_GET(self):
        if self.path in ("/","/index.html"):
            content=Path(__file__).with_name("index.html").read_bytes()
            self.send_response(200); self.send_header("Content-Type","text/html; charset=utf-8"); self.end_headers()
            self.wfile.write(content)
        else:
            self.send_response(404); self.end_headers()

if __name__=="__main__":
    print(f"Tripple M Scanner running on http://localhost:{PORT}")
    print("AI mode:", "enabled" if API_KEY else "demo mode (no API key)")
    HTTPServer((HOST,PORT),Handler).serve_forever()
