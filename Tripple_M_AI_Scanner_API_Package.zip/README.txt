TRIPPLE M AI BUSINESS OPPORTUNITY SCANNER — API EDITION

Run locally:
1. Install Python 3.
2. Open a terminal in this folder.
3. Set your API key ONLY as an environment variable:
   Linux/macOS: export OPENAI_API_KEY="your_key_here"
   Windows PowerShell: $env:OPENAI_API_KEY="your_key_here"
4. Run: python server.py
5. Open: http://localhost:8080

If OPENAI_API_KEY is absent, the app runs in DEMO mode so you can test the interface without spending API credits.

IMPORTANT:
- Never put the secret API key in index.html or public JavaScript.
- For a public deployment, set OPENAI_API_KEY in the hosting provider's server environment.
- The default model is gpt-5.6-luna; change OPENAI_MODEL if desired.
- The AI output is an estimate and should be validated with the real business owner.
